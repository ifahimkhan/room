package ml.fahimkhan.roommvvm.room;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity (tableName = "notes_table")
public class Note {

    @PrimaryKey(autoGenerate = true)
    int id;
    String priority;
    String task;
    String description;
    String byy;

    public Note(String priority, String task, String description, String byy) {
        this.priority = priority;
        this.task = task;
        this.description = description;
        this.byy = byy;
    }

    public String getbyy() {
        return byy;
    }

    public void setbyy(String byy) {
        this.byy = byy;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
