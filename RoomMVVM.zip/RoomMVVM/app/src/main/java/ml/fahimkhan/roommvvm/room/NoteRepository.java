package ml.fahimkhan.roommvvm.room;

import android.app.Application;
import android.os.AsyncTask;

import java.util.List;

import androidx.lifecycle.LiveData;

public class NoteRepository {

    private NoteDao noteDao;
    private LiveData<List<Note>> listLiveData;

    private InsertAsyncTask insertAsyncTask;
    private DeleteAsyncTask deleteAsyncTask;
    private updateAsyncTask updateAsyncTask;
    private DeleteAllAsyncTask deleteAllAsyncTask;

    NoteRepository(Application application) {

        NoteDatabase noteDatabase = NoteDatabase.getInstance(application);
        noteDao = noteDatabase.noteDao();
        listLiveData = noteDao.selectAllNotes();


    }


    void insert(Note note) {

        insertAsyncTask = new InsertAsyncTask(noteDao);
        insertAsyncTask.execute(note);
    }

    public void update(Note note) {

        updateAsyncTask = new updateAsyncTask(noteDao);
        updateAsyncTask.execute(note);
    }


    public void delete(Note note) {

        deleteAsyncTask = new DeleteAsyncTask(noteDao);
        deleteAsyncTask.execute(note);
    }


    public void deleteAllNotes() {

        deleteAllAsyncTask = new DeleteAllAsyncTask(noteDao);
        deleteAllAsyncTask.execute();

    }

    LiveData<List<Note>> getAllNotes() {
        return listLiveData;
    }


    private  static class InsertAsyncTask extends AsyncTask<Note, Void, Void> {

        NoteDao noteDao;

        public InsertAsyncTask(NoteDao noteDao) {
            this.noteDao = noteDao;
        }

        @Override
        protected Void doInBackground(Note... notes) {
            noteDao.insert(notes[0]);
            return null;
        }
    }

    private static class updateAsyncTask extends AsyncTask<Note, Void, Void> {

        NoteDao noteDao;

        updateAsyncTask(NoteDao noteDao) {
            this.noteDao = noteDao;
        }

        @Override
        protected Void doInBackground(Note... notes) {
            noteDao.update(notes[0]);
            return null;
        }
    }

    private static class DeleteAsyncTask extends AsyncTask<Note, Void, Void> {

        NoteDao noteDao;

        DeleteAsyncTask(NoteDao noteDao) {
            this.noteDao = noteDao;
        }

        @Override
        protected Void doInBackground(Note... notes) {
            noteDao.delete(notes[0]);
            return null;
        }
    }

    private static class DeleteAllAsyncTask extends AsyncTask<Void, Void, Void> {

        NoteDao noteDao;

        DeleteAllAsyncTask(NoteDao noteDao) {
            this.noteDao = noteDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            noteDao.deleteAllNotes();
            return null;
        }
    }


}
