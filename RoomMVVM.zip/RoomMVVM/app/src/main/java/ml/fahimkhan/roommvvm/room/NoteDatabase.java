package ml.fahimkhan.roommvvm.room;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {Note.class}, version = 3)
abstract class NoteDatabase extends RoomDatabase {

    private static NoteDatabase instance;


    abstract NoteDao noteDao();

    static final Migration MIGRATION_1_2 = new Migration(2, 3) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            database.execSQL("ALTER TABLE notes_table  "
                    + " ADD COLUMN byy TEXT");
        }
    };

    static synchronized NoteDatabase getInstance(Context context) {
        if (instance == null) {

            instance = Room.databaseBuilder(context.getApplicationContext(),
                    NoteDatabase.class,
                    "note_database")
                    .addMigrations(MIGRATION_1_2)
                    .addCallback(callback).build();
        }
        return instance;
    }


    private static RoomDatabase.Callback callback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbAsyncTask(instance.noteDao()).execute();
        }
    };

    private static class PopulateDbAsyncTask extends AsyncTask<Void, Void, Void> {
        NoteDao noteDao;

        PopulateDbAsyncTask(NoteDao noteDao) {
            this.noteDao = noteDao;

        }

        @Override
        protected Void doInBackground(Void... voids) {

            for (int i = 1; i <= 3; i++) {

                Note note = new Note(String.valueOf(i), "TITLE  " + i, "This is new Created Task..." + i,"FAHIM KHAN "+i);
                noteDao.insert(note);

            }
            return null;
        }
    }
}
