package ml.fahimkhan.roommvvm;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ml.fahimkhan.roommvvm.room.Note;
import ml.fahimkhan.roommvvm.room.NoteViewModel;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    NoteViewModel noteViewModel;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupRecyclerView();


    }


    private void setupRecyclerView() {

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.app_name));
        toolbar.setSubtitle(getString(R.string.app_name));
        toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.white));
        toolbar.setSubtitleTextColor(ContextCompat.getColor(this, R.color.white));
        toolbar.setLogo(R.mipmap.ic_launcher_round);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.recycler);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        noteViewModel = ViewModelProviders.of(this).get(NoteViewModel.class);
        noteViewModel.getAllNotes().observe(this, new Observer<List<Note>>() {
            @Override
            public void onChanged(List<Note> notes) {
                final NoteAdapter noteAdapter = new NoteAdapter();
                noteAdapter.setListLiveData(notes);
                recyclerView.setAdapter(noteAdapter);
                noteAdapter.notifyDataSetChanged();
            }
        });
    }

    public void add(View view) {

        final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);

        // ...Irrelevant code for customizing the buttons and title

        LayoutInflater inflater = this.getLayoutInflater();

        final View dialogView = inflater.inflate(R.layout.dialog, null);
        dialogBuilder.setView(dialogView);

        Button button = dialogView.findViewById(R.id.addNote);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Commond here......
                EditText task = dialogView.findViewById(R.id.title);
                EditText desc = dialogView.findViewById(R.id.desc);
                EditText pri = dialogView.findViewById(R.id.priority);
                EditText by=dialogView.findViewById(R.id.by);
                noteViewModel.insert(new Note(pri.getText().toString(),task.getText().toString(),desc.getText().toString(),by.getText().toString()));
                dialogBuilder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        dialog.dismiss();
                    }
                });
            }
        });



        dialogBuilder.create().show();
    }
}
