package ml.fahimkhan.roommvvm;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import ml.fahimkhan.roommvvm.room.Note;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {



    private List<Note> listLiveData;

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {

        holder.title.setText(listLiveData.get(position).getTask());
        holder.desc.setText(listLiveData.get(position).getDescription());
        holder.priority.setText(listLiveData.get(position).getPriority());
        holder.by.setText(listLiveData.get(position).getbyy());

    }

    @Override
    public int getItemCount() {
        return listLiveData.size();
    }

    public class NoteViewHolder extends RecyclerView.ViewHolder {
        TextView title,desc,priority,by;
        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            title=itemView.findViewById(R.id.title);
            desc=itemView.findViewById(R.id.desc);
            priority=itemView.findViewById(R.id.priority);
            by=itemView.findViewById(R.id.by);
        }

    }

    public void setListLiveData(List<Note> listLiveData) {
        this.listLiveData = listLiveData;
    }

}
